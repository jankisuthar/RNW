
const express=require('express');
const { getAllEmp, addEmp, updateEmp, deleteEmp, ui } = require('../Controller/EmpController');
const { findByIdAndDelete } = require('../Database/model');

const router=express.Router();


router.get("/emp",async(req,res)=>{
    let employee=await getAllEmp();
     res.cookie("name","data").send(employee)
    console.log(req.cookies.name)
})


router.post("/emp",async(req,res)=>{
   // console.log("jjj",req.body)
    let employee=await addEmp(req.body);
   
    return res.send({
        data:employee
    })
})

router.patch("/emp/:id",async(req,res)=>{

    let employee=await updateEmp(req.params.id,req.body);
   
    return res.send({
        data:employee
    })
})

router.delete("/emp/:id",async(req,res)=>{
   try {
    let employee=await deleteEmp(req.params.id);
   
    return res.send({
        data:employee
    })
   } catch (error) {
      return res.status(404).send({
        msg:"unexpected"
      })
   }
   
})

router.get("/",ui)

module.exports=router