const mongoose=require('mongoose')

let Employee=mongoose.model('Emp',{
    name:String,
    gender:String
})
module.exports=Employee