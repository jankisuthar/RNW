const userModel = require('../models/user')
exports.show = async (req, res) => {
   const user = await userModel.find();
   res.send(user)
}
exports.create = async (req, res) => {
   var files = req?.files['profile2'];
   var images = [];
   files.forEach(img => {
      images.push(img.filename)
   });
   console.log(images)
   console.log(req?.files['profile1'][0])
   const user = {
      firstname: req.body.firstname,
      email: req.body.email,
      profile1: req?.files['profile1'][0].filename,
      profile2: images// req.file.filename
   }
   await new userModel(user).save().then(() => {
      res.json({ msg: "data inserted" })
   }
   ).catch((err) => {
      res.json({ error: err })
   })
}

exports.update = async (req, res) => {
   // const id = req.query.id;
   const id = req.params.id;
   const user = await userModel.findById(id);
   if (user) {
      await userModel.findByIdAndUpdate({ _id: id },
         { firstname: req.body.firstname, email: req.body.email })
         .then(() => {
            res.json({ msg: "update" })
         })
   } else {
      res.json({ error: "user not found" })
   }

}

exports.trash = async (req, res) => {
   const id = req.params.id;
   const user = await userModel.findById(id);
   if (user) {
      await userModel.findByIdAndDelete(id)
         .then(() => { res.json({ msg: "delete" }) })
         .catch(() => { res.json({ error: error }) })
   } else {
      res.json({ error: "user not found" })
   }

}